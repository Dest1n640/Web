console.log("Hello world");
alert("Hello");
let a = confirm("Confirm the messege");
console.log(a);
let res = prompt("Quest?");
console.log(res);   
let n = "10";
let s = "10";
console.log(+n + +s)